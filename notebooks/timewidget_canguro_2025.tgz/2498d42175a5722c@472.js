function _1(md){return(
md`# TimeWidget example

Other examples

* [Colombian Election Tweets](https://observablehq.com/@john-guerra/timesearcher-tweets-example)
* [PISA indexes](https://observablehq.com/@john-guerra/timesearcher-oecd)
* [Basic weather demo](https://observablehq.com/@john-guerra/timesearcher-demo-weather)
* [NSF Universities research investment](https://ncses.nsf.gov/surveys/higher-education-research-development/2022)`
)}

function _selected(TimeWidget,unemployment){return(
TimeWidget(unemployment, {
  showBrushesControls: true,
  y: "unemployment",
  x: (d) => d.date,
  id: (d) => d.division,
  // color:  d=> d.division.split(",")[0]
})
)}

function _3(Inputs,selected){return(
Inputs.table(selected.asArray())
)}

function _4($0){return(
($0).brushesCoordinates
)}

function _5(unemployment){return(
unemployment
)}

function _6(selected,htl,fmtX,fmtY,$0)
{
  const brushesElements = Array.from(selected.status.entries())
    .map(([brushGroupid, bgm]) => {
      console.log("bgm", bgm.brushes)
      const brushesElements = Array.from(bgm.brushes.entries()).map(([brushId, b]) => {
        if (!b.selection) return;
        return htl.html`<div>
          <div>Selected: ${b?.isSelected} Active: ${b?.isActive}</div>

          <label>From: <output class="x0" contenteditable="true">${fmtX(
            b.selection[0][0]
          )}</output> <strong>x</strong> <output class="y0" contenteditable="true">${fmtY(
          b.selection[0][1]
        )} </output > 
          </label>
          <br/>
          <label>To: <output class="x1" contenteditable="true">${fmtX(
            b.selection[1][0]
          )}</output> x <output class="y1" contenteditable="true">${fmtY(
          b.selection[1][1]
        )}</output>
          </label>
          </div>`;
      });

      const detailsEle = htl.html`<details>
          <summary>Group <svg width=20 height=20>
              <rect fill=${$0.ts.colorScale(
                brushGroupid
              )} width=20 height=20></rect>
            </svg>
          </summary>
          ${brushesElements}
        </details>
    `;

      // Open if it contains the current one
      if (
        Array.from(bgm.brushes.values())
          .flat()
          .filter((b) => b.isActive).length
      )
        detailsEle.querySelector("details").setAttribute("open", null);
      return detailsEle;
    })
    .flat();

  return htl.html`
<form action="">
<h2>Brushes</h2>
${brushesElements}
<button>Update</button>
</form>
`;
}


function _7(selected){return(
selected.status
)}

function _fmtY(d3){return(
d3.format(".2f")
)}

function _fmtX(d3){return(
d3.timeFormat("%d/%m/%y")
)}

function _10(Generators,$0){return(
Generators.observe(notify => {
  $0.ts.statusCallback((data) => notify(data))
})
)}

function _11($0){return(
($0.ts).statusCallback
)}

function _12(selected)
{
  selected;
  return selected.brushes
}


function _13(selected){return(
selected.brushes
)}

function _15(Inputs,unemployment){return(
Inputs.table(unemployment)
)}

function _unemployment(FileAttachment){return(
FileAttachment("bls-metro-unemployment.csv").csv({typed: true})
)}

async function _TimeWidget(require,FileAttachment)
{
  try {
    console.log("Trying to load timesearcher local")
    return await require(`http://localhost:8080/dist/TimeWidget.js?${Date.now()}`);
  } catch (e) {
    try {
      console.log("Failed. Trying to load timesearcher from a File Attachment");
      return await require(await FileAttachment("TimeWidget@2.js").url());
    } catch (e2) {
      console.log("Failed. Trying to load timesearcher from NPM");
      return await require("time-widget");
    }
  }
}


function _TimeSearcher(TimeWidget){return(
TimeWidget
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["bls-metro-unemployment.csv", {url: new URL("./files/cf77aaa2e0dab4123d57f8421210e5fa6955d75017369c93e3086b7369e4a040e398ed494b71d541a9c0c72575ac29cdc9e7038b6ae681cc1d761fec2c99a85f.csv", import.meta.url), mimeType: "text/csv", toString}],
    ["TimeWidget@2.js", {url: new URL("./files/09dc67b685762336438e5503d05b13d85363499c8d411a87d0235e69d5eccbb5e22feddabc91ea244e3115ce21b6c19eed2a062d024cc37837eb0247a3ccb0f8.js", import.meta.url), mimeType: "application/javascript", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("viewof selected")).define("viewof selected", ["TimeWidget","unemployment"], _selected);
  main.variable(observer("selected")).define("selected", ["Generators", "viewof selected"], (G, _) => G.input(_));
  main.variable(observer()).define(["Inputs","selected"], _3);
  main.variable(observer()).define(["viewof selected"], _4);
  main.variable(observer()).define(["unemployment"], _5);
  main.variable(observer()).define(["selected","htl","fmtX","fmtY","viewof selected"], _6);
  main.variable(observer()).define(["selected"], _7);
  main.variable(observer("fmtY")).define("fmtY", ["d3"], _fmtY);
  main.variable(observer("fmtX")).define("fmtX", ["d3"], _fmtX);
  main.variable(observer()).define(["Generators","viewof selected"], _10);
  main.variable(observer()).define(["viewof selected"], _11);
  main.variable(observer()).define(["selected"], _12);
  main.variable(observer()).define(["selected"], _13);
  main.variable(observer()).define(["Inputs","unemployment"], _15);
  main.variable(observer("unemployment")).define("unemployment", ["FileAttachment"], _unemployment);
  main.variable(observer("TimeWidget")).define("TimeWidget", ["require","FileAttachment"], _TimeWidget);
  main.variable(observer("TimeSearcher")).define("TimeSearcher", ["TimeWidget"], _TimeSearcher);
  return main;
}
