import define1 from "./1371b3b2446a73b4@335.js";

function _1(md){return(
md`# To Stages`
)}

function _data(dataInput){return(
dataInput()
)}

function _3(data){return(
data
)}

function _xAttr(){return(
"__stageId"
)}

function _yAttr(){return(
"peso"
)}

function _groupAttr(){return(
"Iden_Codigo"
)}

function _renderer(){return(
"canvas"
)}

function _stages()
{
  var a = [
    {
      id: 0,
      name: "Entorno",
      variables: []
    },
    {
      id: 1,
      name: "Embarazo y pre-parto",
      variables: []
    },
    {
      id: 2,
      time: "ERN_Ballard",
      name: "Nacimiento",
      variables: [
        {
          name: "peso",
          var: "ERN_Peso"
        },
        {
          name: "talla",
          var: "ERN_Talla"
        },
        { name: "PC", var: "ERN_PC" },
        { name: "zscorepeso", var: "zscorepesonacerF" },
        { name: "zscorepeso-con40sOMS", var: "zscorepesonacerF" },
        {
          name: "zscorepesoparatalla",
          var: "zscorefinalBMI_FOR_AGE_NACER"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "zscorefinalBMI_FOR_AGE_NACER"
        },
        { name: "zscoretalla", var: "zscoretallanacerF" },
        { name: "zscoretalla-con40sOMS", var: "zscoretallanacerF" },
        { name: "zscoreperimetrosC", var: "zscoreperimetrosCnacerF" },
        { name: "zscoreperimetrosC-con40sOMS", var: "zscoreperimetrosCnacerF" }
      ]
    },
    {
      id: 3,
      time: "gestasal",
      name: "hosp-neonatal",
      variables: [
        {
          name: "peso",
          var: "HD_PesoSalida"
        }
      ]
    },
    {
      id: 4,
      time: "egestasalPC",
      name: "Entrada Programa Canguro",
      variables: [
        {
          name: "peso",
          var: "V196A"
        },
        {
          name: "talla",
          var: "V196B"
        },
        { name: "PC", var: "V196C" },
        { name: "zscorepeso", var: "zscorepesoEntFenton2013" },
        { name: "zscorepeso-con40sOMS", var: "zscorepesoEntFenton2013" },
        {
          name: "zscorepesoparatalla",
          var: "zscorefinalpesoparalatallaalasalida_entrada"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "zscorefinalpesoparalatallaalasalida_entrada"
        },
        { name: "zscoretalla", var: "zscoretallaEntFenton2013" },
        { name: "zscoretalla-con40sOMS", var: "zscoretallaEntFenton2013" },
        {
          name: "zscoreperimetrosC",
          var: "zscorePerimetroCEntFenton2013"
        },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "zscorePerimetroCEntFenton2013"
        }
      ]
    },
    {
      id: 5,
      name: "Semana 40",
      time: 40,
      variables: [
        {
          name: "peso",
          var: "V218"
        },
        {
          name: "talla",
          var: "V219"
        },
        {
          name: "PC",
          var: "V220"
        },
        { name: "zscorepeso", var: "Fenton2013finalzscorepeso40Sem" },
        { name: "zscorepeso-con40sOMS", var: "zscorepeso40semOMS" },
        {
          name: "zscorepesoparatalla",
          var: "zscorefinalpesoparalatalla40semanas"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "zscorefinalpesoparalatalla40semanas"
        },
        { name: "zscoretalla", var: "Fenton2013finalzscoretalla40Sem" },
        { name: "zscoretalla-con40sOMS", var: "zscoretalla40semOMS" },
        {
          name: "zscoreperimetrosC",
          var: "Fenton2013finalzscorePerimetroC40Sem"
        },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "zscorePerimetroC40semOMS"
        },
        { name: "LecheMaternaExclusiva", var: "LME40" },
        { name: "ConLecheMaterna", var: "algoLM40sem" }
      ]
    },
    {
      id: 6,
      name: "Mes 3",
      time: 53,
      variables: [
        {
          name: "peso",
          var: "V261"
        },
        {
          name: "talla",
          var: "V262"
        },
        {
          name: "PC",
          var: "V263"
        },
        { name: "zscorepeso", var: "zscorepeso3mOMS" },
        { name: "zscorepeso-con40sOMS", var: "zscorepeso3mOMS" },
        {
          name: "zscorepesoparatalla",
          var: "zscorepesoparatalla3meses"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "zscorepesoparatalla3meses"
        },
        { name: "zscoretalla", var: "zscoretalla3mOMS" },
        { name: "zscoretalla-con40sOMS", var: "zscoretalla3mOMS" },
        { name: "zscoreperimetrosC", var: "zscorePerimetroC3mOMS" },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "zscorePerimetroC3mOMS"
        },
        { name: "LecheMaternaExclusiva", var: "LME3m" },
        { name: "ConLecheMaterna", var: "algoLM3meses" }
      ]
    },
    {
      id: 7,
      name: "Mes 6",
      time: 66,
      variables: [
        {
          name: "peso",
          var: "V304"
        },
        {
          name: "talla",
          var: "V305"
        },
        {
          name: "PC",
          var: "V306"
        },
        { name: "zscorepeso", var: "zscorepeso6mOMS" },
        { name: "zscorepeso-con40sOMS", var: "zscorepeso6mOMS" },

        {
          name: "zscorepesoparatalla",
          var: "zscorepesoparatalla6meses"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "zscorepesoparatalla6meses"
        },
        { name: "zscoretalla", var: "zscoretalla6mOMS" },
        { name: "zscoretalla-con40sOMS", var: "zscoretalla6mOMS" },

        { name: "zscoreperimetrosC", var: "zscorePerimetroC6mOMS" },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "zscorePerimetroC6mOMS"
        },
        { name: "LecheMaternaExclusiva", var: "LME6m" },
        { name: "ConLecheMaterna", var: "algoLM6meses" }
      ]
    },
    {
      id: 8,
      name: "Mes 9",
      time: 79,
      variables: [
        {
          name: "peso",
          var: "V347"
        },
        {
          name: "talla",
          var: "V348"
        },
        {
          name: "PC",
          var: "V349"
        },
        { name: "zscorepeso", var: "zscorepeso9mOMS" },
        { name: "zscorepeso-con40sOMS", var: "zscorepeso9mOMS" },
        {
          name: "zscorepesoparatalla",
          var: "zscorepesoparatalla9meses"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "zscorepesoparatalla9meses"
        },

        { name: "zscoretalla", var: "zscoretalla9mOMS" },
        { name: "zscoretalla-con40sOMS", var: "zscoretalla9mOMS" },
        { name: "zscoreperimetrosC", var: "zscorePerimetroC9mOMS" },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "zscorePerimetroC9mOMS"
        },
        { name: "LecheMaternaExclusiva", var: "LME9m" },
        { name: "ConLecheMaterna", var: "algoLM9meses" }
      ]
    },
    {
      id: 9,
      name: "Mes 12",
      time: 92,
      variables: [
        {
          name: "peso",
          var: "V389"
        },
        {
          name: "talla",
          var: "V390"
        },
        {
          name: "PC",
          var: "V391"
        },
        { name: "zscorepeso", var: "zscorepeso12mOMS" },
        { name: "zscorepeso-con40sOMS", var: "zscorepeso12mOMS" },

        {
          name: "zscorepesoparatalla",
          var: "zscorefinalpesoparatalla12mesesOMS"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "zscoreBMI12mesessegunOMS"
        },
        { name: "zscoretalla", var: "zscoretalla12mOMS" },
        { name: "zscoretalla-con40sOMS", var: "zscoretalla12mOMS" },
        { name: "zscoreperimetrosC", var: "zscorePerimetroC12mOMS" },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "zscorePerimetroC12mOMS"
        },
        { name: "LecheMaternaExclusiva", var: "LME12m" },
        { name: "ConLecheMaterna", var: "algoLM12meses" }
      ]
    }
  ];

  return a;
}


function _stages20a()
{
  var a = [
    {
      id: 0,
      name: "Entorno",
      variables: []
    },
    {
      id: 1,
      name: "Embarazo y pre-parto",
      variables: []
    },
    {
      id: 2,
      time: "BIRTH_ballar5",
      name: "Nacimiento",
      variables: [
        {
          name: "peso",
          var: "BIRTH_peso5"
        },
        {
          name: "talla",
          var: "BIRTH_talla5"
        },
        { name: "PerimetroC", var: "BIRTH_pc5" },
        { name: "zscorepeso", var: "BIRTH_zscorepesonacerF" },
        { name: "zscorepeso-con40sOMS", var: "BIRTH_zscorepesonacerF" },
        {
          name: "zscorepesoparatalla",
          var: "BIRTH_zscorefinalBMI_FOR_AGE_NACER"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "BIRTH_zscorefinalBMI_FOR_AGE_NACER"
        },
        { name: "zscoretalla", var: "BIRTH_zscoretallanacerF" },
        { name: "zscoretalla-con40sOMS", var: "BIRTH_zscoretallanacerF" },
        { name: "zscoreperimetrosC", var: "BIRTH_zscoreperimetrosCnacerF" },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "BIRTH_zscoreperimetrosCnacerF"
        }
      ]
    },
    {
      id: 3,
      time: "gestasal",
      name: "hosp-neonatal",
      variables: [
        {
          name: "peso",
          var: "HD_PesoSalida"
        }
      ]
    },
    {
      id: 4,
      time: "EGSal",
      name: "Entrada Programa Canguro",
      variables: [
        {
          name: "peso",
          var: "NEO_pesosal"
        },
        {
          name: "talla",
          var: null
        },
        { name: "PerimetroC", var: null },
        { name: "zscorepeso", var: "NEO_zscorepesoEntFenton2013" },
        { name: "zscorepeso-con40sOMS", var: "NEO_zscorepesoEntFenton2013" },
        {
          name: "zscorepesoparatalla",
          var: "NEO_zscorefinalpesoparalatallaalasalida_entrada"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "NEO_zscorefinalpesoparalatallaalasalida_entrada"
        },
        { name: "zscoretalla", var: "NEO_zscoretallaEntFenton2013" },
        { name: "zscoretalla-con40sOMS", var: "NEO_zscoretallaEntFenton2013" },
        {
          name: "zscoreperimetrosC",
          var: "NEO_zscorePerimetroCEntFenton2013"
        },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "NEO_zscorePerimetroCEntFenton2013"
        }
      ]
    },
    {
      id: 5,
      name: "Semana 40",
      time: 40,
      variables: [
        {
          name: "peso",
          var: "EX41_peso8"
        },
        {
          name: "talla",
          var: "EX41_talla8"
        },
        {
          name: "PerimetroC",
          var: "EX41_pc8"
        },
        { name: "zscorepeso", var: "EX41_Fenton2013finalzscorepeso40Sem" },
        { name: "zscorepeso-con40sOMS", var: "EX41_zscorepeso40SemOMS" },
        {
          name: "zscorepesoparatalla",
          var: "EX41_zscorefinalpesoparalatalla40semanas"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "EX41_zscorefinalpesoparalatalla40semanas"
        },
        { name: "zscoretalla", var: "EX41_Fenton2013finalzscoretalla40Sem" },
        { name: "zscoretalla-con40sOMS", var: "zscoretalla40semOMS" },
        {
          name: "zscoreperimetrosC",
          var: "EX41_Fenton2013finalzscorePerimetroC40Sem"
        },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "zscorePerimetroC40semOMS"
        },
        { name: "LecheMaternaExclusiva", var: "LME40" },
        { name: "ConLecheMaterna", var: "algoLM40sem" }
      ]
    },
    {
      id: 6,
      name: "Mes 3",
      time: 53,
      variables: [
        {
          name: "peso",
          var: "FOLL12M_peso9"
        },
        {
          name: "talla",
          var: "FOLL12M_talla9"
        },
        {
          name: "PerimetroC",
          var: "FOLL12M_pc9"
        },
        { name: "zscorepeso", var: "NUT_zscorepeso3mOMS" },
        { name: "zscorepeso-con40sOMS", var: "NUT_zscorepeso3mOMS" },
        {
          name: "zscorepesoparatalla",
          var: "NUT_zscorepesoparatalla3meses"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "NUT_zscorepesoparatalla3meses"
        },
        { name: "zscoretalla", var: "NUT_zscoretalla3mOMS" },
        { name: "zscoretalla-con40sOMS", var: "NUT_zscoretalla3mOMS" },
        { name: "zscoreperimetrosC", var: "NUT_zscorePerimetroC3mOMS" },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "NUT_zscorePerimetroC3mOMS"
        },
        { name: "LecheMaternaExclusiva", var: "LME3m" },
        { name: "ConLecheMaterna", var: "algoLM3meses" }
      ]
    },
    {
      id: 7,
      name: "Mes 6",
      time: 66,
      variables: [
        {
          name: "peso",
          var: "FOLL12M_peso10"
        },
        {
          name: "talla",
          var: "FOLL12M_talla10"
        },
        {
          name: "PerimetroC",
          var: "FOLL12M_pc10"
        },
        { name: "zscorepeso", var: "NUT_zscorepeso6mOMS" },
        { name: "zscorepeso-con40sOMS", var: "NUT_zscorepeso6mOMS" },

        {
          name: "zscorepesoparatalla",
          var: "NUT_zscorepesoparatalla6meses"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "NUT_zscorepesoparatalla6meses"
        },
        { name: "zscoretalla", var: "NUT_zscoretalla6mOMS" },
        { name: "zscoretalla-con40sOMS", var: "NUT_zscoretalla6mOMS" },

        { name: "zscoreperimetrosC", var: "NUT_zscorePerimetroC6mOMS" },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "NUT_zscorePerimetroC6mOMS"
        },
        { name: "LecheMaternaExclusiva", var: "LME6m" },
        { name: "ConLecheMaterna", var: "algoLM6meses" }
      ]
    },
    {
      id: 8,
      name: "Mes 9",
      time: 79,
      variables: [
        {
          name: "peso",
          var: "FOLL12M_peso11"
        },
        {
          name: "talla",
          var: "FOLL12M_talla11"
        },
        {
          name: "PerimetroC",
          var: "FOLL12M_pc11"
        },
        { name: "zscorepeso", var: "NUT_zscorepeso9mOMS" },
        { name: "zscorepeso-con40sOMS", var: "NUT_zscorepeso9mOMS" },
        {
          name: "zscorepesoparatalla",
          var: "NUT_zscorepesoparatalla9meses"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "NUT_zscorepesoparatalla9meses"
        },

        { name: "zscoretalla", var: "NUT_zscoretalla9mOMS" },
        { name: "zscoretalla-con40sOMS", var: "NUT_zscoretalla9mOMS" },
        { name: "zscoreperimetrosC", var: "NUT_zscorePerimetroC9mOMS" },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "NUT_zscorePerimetroC9mOMS"
        },
        { name: "LecheMaternaExclusiva", var: "LME9m" },
        { name: "ConLecheMaterna", var: "algoLM9meses" }
      ]
    },
    {
      id: 9,
      name: "Mes 12",
      time: 92,
      variables: [
        {
          name: "peso",
          var: "FOLL12M_peso12"
        },
        {
          name: "talla",
          var: "FOLL12M_talla12"
        },
        {
          name: "PerimetroC",
          var: "FOLL12M_pc12"
        },
        { name: "zscorepeso", var: "NUT_zscorepeso12mOMS" },
        { name: "zscorepeso-con40sOMS", var: "NUT_zscorepeso12mOMS" },

        {
          name: "zscorepesoparatalla",
          var: "NUT_zscorefinalpesoparatalla12mesesOMS"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "FOLL12M_zscoreBMI12mesessegunOMS"
        },
        { name: "zscoretalla", var: "NUT_zscoretalla12mOMS" },
        { name: "zscoretalla-con40sOMS", var: "NUT_zscoretalla12mOMS" },
        { name: "zscoreperimetrosC", var: "NUT_zscorePerimetroC12mOMS" },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "NUT_zscorePerimetroC12mOMS"
        },
        { name: "LecheMaternaExclusiva", var: "LME12m" },
        { name: "ConLecheMaterna", var: "algoLM12meses" }
      ]
    },
    {
      id: 10,
      name: "20 Años",
      time: 121,
      variables: [
        {
          name: "peso",
          var: "PEDIATRIC_weight"
        },
        {
          name: "talla",
          var: "PEDIATRIC_height"
        },
        {
          name: "PerimetroC",
          var: "PEDIATRIC_PerimetroCefalico"
        },
        { name: "zscorepeso", var: "PEDIATRIC_WeightZ_CDC" },
        { name: "zscorepeso-con40sOMS", var: "PEDIATRIC_WeightZ_CDC" },
        {
          name: "zscorepesoparatalla",
          var: "PEDIATRIC_BMIZ_CDC"
        },
        {
          name: "zscorepesoparalatallaBMI-OMS",
          var: "PEDIATRIC_BMIZ_CDC"
        },
        { name: "zscoretalla", var: "PEDIATRIC_HeightZ_CDC" },
        { name: "zscoretalla-con40sOMS", var: "PEDIATRIC_HeightZ_CDC" },
        { name: "zscoreperimetrosC", var: "PEDIATRIC_zscorehc_Rollins" },
        {
          name: "zscoreperimetrosC-con40sOMS",
          var: "PEDIATRIC_zscorehc_Rollins"
        }
      ]
    }
  ];

  return a;
}


function _dataF(data){return(
data
)}

function _grouped(d3,tData){return(
d3.group(tData, d => d["Code"])
)}

function _tData(transformData,dataF,stages){return(
transformData(dataF,"Code",stages,"ERN_Sexo")
)}

function _transformData(){return(
function transformData(data, ident, stages, groupAttr) {
  debugger;
  let tData = [];
  stages.forEach((stage) => {
    data.forEach((r) => {
      let time = typeof stage.time === "number" ? stage.time : r[stage.time];
      let row = {
        [ident]: r[ident],
        __stageName: stage.name,
        __stageId: stage.id,
        __time: time
      };
      if (groupAttr) {
        row = { ...row, [groupAttr]: r[groupAttr] };
      }
      if (stage.variables.length > 0) {
        stage.variables.forEach((v) => {
          row = { ...row, [v.name]: r[v.var] };
        });
        tData.push(row);
      }
    });
  });
  return tData;
}
)}

function _computeId(){return(
function computeId (data,key1,key2) {
  data.forEach(d => d["__Id"] = d[key1] + 100000 * d[key2])
  return data;
}
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("viewof data")).define("viewof data", ["dataInput"], _data);
  main.variable(observer("data")).define("data", ["Generators", "viewof data"], (G, _) => G.input(_));
  main.variable(observer()).define(["data"], _3);
  main.variable(observer("xAttr")).define("xAttr", _xAttr);
  main.variable(observer("yAttr")).define("yAttr", _yAttr);
  main.variable(observer("groupAttr")).define("groupAttr", _groupAttr);
  main.variable(observer("renderer")).define("renderer", _renderer);
  main.variable(observer("stages")).define("stages", _stages);
  main.variable(observer("stages20a")).define("stages20a", _stages20a);
  main.variable(observer("dataF")).define("dataF", ["data"], _dataF);
  main.variable(observer("grouped")).define("grouped", ["d3","tData"], _grouped);
  main.variable(observer("tData")).define("tData", ["transformData","dataF","stages"], _tData);
  main.variable(observer("transformData")).define("transformData", _transformData);
  main.variable(observer("computeId")).define("computeId", _computeId);
  const child1 = runtime.module(define1);
  main.import("dataInput", child1);
  return main;
}
