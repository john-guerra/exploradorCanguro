import define1 from "./2498d42175a5722c@472.js";
import define2 from "./b205fb52cf643a23@402.js";
import define3 from "./e76d2c695f356743@796.js";

function _1(md){return(
md`# TimeWidget Canguro 2025 Data`
)}

function _curvas(FileAttachment){return(
FileAttachment("curvasv2.json").json()
)}

function _8(data){return(
[...Object.keys(data[0])].filter(a => a.toLowerCase().includes("gestasal"))
)}

function _10(TimeWidget,data){return(
TimeWidget(data.slice(0, 1000).filter(d => d.gestasal).map(d => ({...d})), {
  y: "talla",
  x: "gestasal",
  id: "Iden_Codigo",
  xLabel: "→ EG (Weeks)",
  yLabel: "↑ Talla (Cm)",
  // defaultAlpha: 0.1,
  // alphaScale: d3.scalePow().exponent(0.2).range([1, 0.1]),
  // referenceCurves: curvas
})
)}

function _11(navio,data){return(
navio([...data.map(d => ({...d}))])
)}

function _12(md){return(
md`## Reading data from parquet`
)}

function _data(__query,db,invalidation){return(
__query.sql(db,invalidation,"db")`SELECT * FROM canguro
  
-- WHERE peso < 15000 AND
--   "__time" > 20 AND "__time" < 93`
)}

function _db(DuckDBClient,FileAttachment){return(
DuckDBClient.of({
  canguro: FileAttachment("base total 93-2024 base de obesidad 17.parquet")

  // dane: FileAttachment("COD_DANE_DIVIPOLA_CentrosPoblados.csv")
})
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["base total 93-2024 base de obesidad 17.parquet", {url: new URL("./files/3cd27dd75d8b3768c14b89fcd06767722204e30486dcae6ea5c16a26a1fab116f8520ea663516ef2e1cca6e0afdd7e69ac628b4d4201b95366b0b3c0731591b9.bin", import.meta.url), mimeType: "application/octet-stream", toString}],
    ["curvasv2.json", {url: new URL("./files/e5506b7258e4379db5cebcc0551b452c8cf9c11d38dac8224b0388d22a017cceecad809a7894c568e3ec22644b248971ef6a59ce9f9b74ecc29e29261c8b343e.json", import.meta.url), mimeType: "application/json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("curvas")).define("curvas", ["FileAttachment"], _curvas);
  const child1 = runtime.module(define1);
  main.import("TimeWidget", child1);
  const child2 = runtime.module(define2);
  main.import("transformData", child2);
  main.import("stages", child2);
  const child3 = runtime.module(define3);
  main.import("navio", child3);
  main.variable(observer()).define(["data"], _8);
  main.variable(observer()).define(["TimeWidget","data"], _10);
  main.variable(observer()).define(["navio","data"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer("data")).define("data", ["__query","db","invalidation"], _data);
  main.variable(observer("db")).define("db", ["DuckDBClient","FileAttachment"], _db);
  return main;
}
