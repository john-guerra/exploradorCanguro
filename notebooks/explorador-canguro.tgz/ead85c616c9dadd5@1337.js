import define1 from "./7a9e12f9fb3d8e06@498.js";

function _1(md){return(
md`# Violin Plot (WIP)

A reusable violin plot chart using [Kernel Densities via [fast-kde](https://www.npmjs.com/package/fast-kde) that can also draw the histogram for comparison

__Kernel Density Estimation Parameters__`
)}

function _bandwidth(Inputs){return(
Inputs.range([1, 20], {value: 7, step: 0.1, label: "Bandwidth"})
)}

function _thresholds(Inputs){return(
Inputs.range([2, 200], {value: 40, step: 1, label: "Threshold"})
)}

function _pad(Inputs){return(
Inputs.range([0, 10], {step: 0.05, value: 4, label: 'Pad'})
)}

function _drawBars(Inputs){return(
Inputs.toggle({label: "Draw Bars for the KDE", value: false})
)}

function _drawHistogram(Inputs){return(
Inputs.toggle({label: "Draw Histogram", value: true})
)}

function _drawPoints(Inputs){return(
Inputs.toggle({label: "Draw Points", value: true})
)}

function _groupBy(Inputs){return(
Inputs.toggle({label: "Group by", value: false })
)}

function _chart(ViolinPlot,penguins,groupBy,width,color,bandwidth,thresholds,pad,drawBars,drawPoints,drawHistogram){return(
ViolinPlot(penguins, {
  groupBy: groupBy ? d => d.species: null,
  value: d => d.culmen_length_mm,
  yLabel: "↑ Culmen Length (mm)",
  width,
  height: 600,
  color: d => color(d.id),
  bandwidth,
  thresholds,
  pad,
  drawBars,
  drawPoints,
  drawHistogram,
  
})
)}

function _facetedChart(FacetViolinPlot,penguins,groupBy,color,bandwidth,thresholds,pad,drawBars,drawPoints,drawHistogram){return(
FacetViolinPlot(penguins, {
  attribs: Object.keys(penguins[0]).filter((attr) => !isNaN(penguins[0][attr])),
  violinOptions: {
    groupBy: groupBy ? (d) => d.species : null,
    color: (d) => (groupBy ? color(d[0]) : "steelblue"),
    bandwidth,
    thresholds,
    pad,
    drawBars,
    drawPoints,
    drawHistogram,
  }
})
)}

function _color(d3){return(
d3.scaleOrdinal(d3.schemeCategory10)
)}

function _chart2(ViolinPlot,compensation,width,bandwidth,thresholds,pad,drawBars){return(
ViolinPlot(compensation, {
  groupBy: d => d["Organization Group"],
  value: d => d["Total Salary"],
  // gDomain: d3.groupSort(compensation, ([d]) => -d["Total Salary"], d => d["Organization Group"]), // sort by descending Salary
  yFormat: ",d",
  yLabel: "Total Salary",
  width,
  height: 500,
  color: "steelblue",
  bandwidth,
  thresholds,
  pad,
  drawBars, 
})
)}

function _compensation(FileAttachment){return(
FileAttachment("SF_Employee_Compensation_2022.csv").csv({
  typed: true
})
)}

function _14(howto){return(
howto("ViolinPlot")
)}

function _ViolinPlot(d3,kde){return(
function ViolinPlot(
  data,
  {
    thresholds = 40,
    bandwidth = 7,
    pad = 4,
    groupBy = null, // given d in data, returns the (ordinal) attribute to group by, null for no grouping
    value = (d) => d, // given d in data, returns the (quantitative) y-value
    title, // given d in data, returns the title text
    marginTop = 20, // the top margin, in pixels
    marginRight = 0, // the right margin, in pixels
    marginBottom = 30, // the bottom margin, in pixels
    marginLeft = 80, // the left margin, in pixels
    width = 640, // the outer width of the chart, in pixels
    height = 500, // the outer height of the chart, in pixels
    gDomain, // an array of (ordinal) x-values
    xRange = [marginLeft, width - marginRight], // [left, right]
    yRange = [height - marginBottom, marginTop], // [bottom, top]
    yDomain, // [ymin, ymax]
    xPadding = 0.1, // amount of x-range to reserve to separate violins
    yFormat, // a format specifier string for the y-axis
    yLabel = "↑ Frequency", // a label for the y-axis
    color = "currentColor", // bar fill color
    drawBars = false,
    drawPoints = false,
    drawHistogram = false,
    drawViolin = true,
    pointsJitter,
    pointR = 2,
    pointStroke = "#333",
    drawXAxis = false
  } = {}
) {
  groupBy = groupBy || (() => "");
  const groups = d3
    .groups(data, groupBy)
    .map(([g, V]) => ({ id: g, V, Y: d3.map(V, value) }));

  let bins; // for histograms

  if (gDomain === undefined) gDomain = groups.map((g) => g.id);
  const gScale = d3.scaleBand(gDomain, xRange).padding(xPadding);
  pointsJitter =
    pointsJitter !== undefined ? pointsJitter : gScale.range()[1] / 8;

  const GDensities = groups
    .map(({ id, V, Y }) => ({
      id,
      densities: Array.from(
        kde.density1d(Y, {
          bandwidth,
          pad,
          bins: thresholds
          // extent: yScale.domain()
        })
      ).map(({ x, y }) => [x, y]),
      Y,
      V
    }))
    .map(({ id, densities, Y, V }) => {
      if (drawHistogram) {
        // Build Bins for histograms using the whole data
        bins = d3
          .bin()
          .thresholds(thresholds)(
            // .thresholds(densities.map((d) => d[0]))
            Y
          )
          .map((b) => Object.assign(b, { realDensity: b.length / Y.length }));
      }

      return {
        id,
        densities,
        histogram: bins,
        Y,
        V
      };
    });

  if (yDomain === undefined)
    yDomain = d3.extent(
      GDensities.map((g) => g.densities.map((d) => d[0])).flat()
    );
  const yScale = d3.scaleLinear().domain(yDomain).range(yRange);
  const thresholdsArray = yScale.ticks(thresholds);
  // console.log("thresholdsArray", thresholdsArray);
  console.log("gD", yDomain, GDensities);

  const maxBinLength = d3.max(GDensities, ({ g, densities }, i) =>
    d3.max(densities, (d) => d[1])
  );

  const xScale = d3
    .scaleLinear()
    .domain([0, maxBinLength * 2])
    .nice()
    .range([0, gScale.bandwidth() * (2 - xPadding)]);

  // console.log("maxBinLength", maxBinLength);

  // Omit any data not present in the x-domain.
  // const I = d3.range(X.length).filter(i => gDomain.has(X[i]));

  // Construct scales, axes, and formats.

  const xAxis = d3.axisBottom(xScale).tickFormat(d3.format(".0%"));
  const gAxis = d3.axisBottom(gScale).tickSizeOuter(0);
  const yAxis = d3.axisLeft(yScale).tickFormat(yFormat);

  // The line generator
  const area = d3
    .area()
    .curve(d3.curveLinear)
    .x0((d) => xScale(-d[1] / 2))
    .x1((d) => xScale(d[1] / 2))
    .y((d) => yScale(d[0]));

  const svg = d3
    .create("svg")
    .attr("width", width)
    .attr("height", height)
    .attr("viewBox", [0, 0, width, height])
    .attr(
      "style",
      "max-width: 100%; height: auto; height: intrinsic; overflow: visible"
    );

  // ------------- Axis --------------
  svg
    .append("g")
    .attr("transform", `translate(${marginLeft},0)`)
    .call(yAxis)
    .call((g) => g.select(".domain").remove())
    .call((g) =>
      g
        .selectAll(".tick line")
        .clone()
        .attr("x2", width - marginLeft - marginRight)
        .attr("stroke-opacity", 0.1)
    )
    .call((g) =>
      g
        .append("text")
        .attr("x", -marginLeft)
        .attr("y", 10)
        .attr("fill", "currentColor")
        .attr("text-anchor", "start")
        .text(yLabel)
    );

  if (drawXAxis) {
    svg
      .append("g")
      .selectAll("g.xAxis")
      .data(GDensities)
      .join("g")
      .attr("class", "xAxis")
      .attr(
        "transform",
        (g) =>
          `translate(${gScale(g.id) + gScale.bandwidth() / 2},${
            height - marginBottom
          })`
      )
      .call(xAxis);
  }

  // Don't draw axis for groups when no group selected
  if (groupBy(data[0])) {
    svg
      .append("g")
      .attr("id", "gAxis")
      .attr(
        "transform",
        `translate(0,${height - marginBottom + marginBottom / 2})`
      )
      .call(gAxis)
      .call((g) => g.select(".domain").remove())
      .call((g) => g.selectAll(".tick line").remove());
  }

  console.log(GDensities);
  // console.log(
  //   GDensities.map((c) => c[1].map((d) => d[1]))
  //     .flat()
  //     .reduce((p, n) => p + n, 0)
  // );

  // ------------- Violin ---------------
  if (drawViolin) {
    const violin = svg
      .append("g")
      .selectAll(".violin")
      .data(GDensities)
      .join("path")
      .attr("fill", color)
      .attr("class", "violin")
      .attr("d", ({ g, densities }) => area(densities))
      .attr(
        "transform",
        ({ id, bins, densities }) =>
          `translate(${gScale(id) + gScale.bandwidth() / 2}, 0)`
      );
  }
  // ---------------- / Violin ----------------

  // ------------- Ticks -----------------
  if (drawPoints) {
    svg
      .append("g")
      .attr("opacity", 0.3)
      .selectAll(".points")
      .data(data.filter((d) => !isNaN(value(d))))
      .join("circle")
      .attr("stroke", pointStroke)
      // .attr("fill", "none")
      .attr("class", "points")
      .attr(
        "cx",
        (d) =>
          gScale(groupBy(d)) +
          gScale.bandwidth() / 2 +
          (Math.random() * pointsJitter - pointsJitter / 2)
      )
      .attr("cy", (d) => yScale(value(d)))
      .attr("r", pointR)
      .append("title")
      .text((d) => `${value(d)} y ${yScale(value(d))}`);
  }

  // -------- Density Bars ----------------
  if (drawBars) {
    const innerHeight = Math.abs(yRange[1] - yRange[0]);
    svg
      .append("g")
      .attr("class", "bars")
      .attr("fill", "#aaaa")
      .selectAll(".barGroup")
      .data(GDensities)
      .join("g")
      .attr("class", "barGroup")
      .each(function ({ g, densities, Y, V }) {
        d3.select(this)
          .selectAll("rect")
          .data(densities)
          .join("rect")
          .attr("x", 0)
          .attr("y", (d) => yScale(d[0]))
          .attr("width", (d) => xScale(d[1]))
          .attr("height", innerHeight / densities.length - 3)
          .append("title")
          .text(
            (d) =>
              `${d[0]} kde density ${d[1]} ${d.length} subsetLength ${
                Y.length
              } densitiy ${d.length / Y.length} realDensity ${d.realDensity}`
          );
      })
      .attr(
        "transform",
        ({ id, bins, densities }) =>
          `translate(${gScale(id) + gScale.bandwidth() / 2}, 0)`
      );
  }

  // --------- Histogram ----------------
  if (drawHistogram) {
    // https://observablehq.com/@d3/histogram
    // Compute bins.

    svg
      .append("g")
      .attr("class", "histogram")
      .attr("fill", "#a4c8caaa")
      .selectAll(".histGroup")
      .data(GDensities)
      .join("g")
      .attr("class", "histGroup")
      .each(function ({ g, densities, histogram, Y, V }) {
        d3.select(this)
          .selectAll("rect")
          .data(histogram)
          .join("rect")
          .attr("x", (d) => -xScale(d.realDensity))
          .attr("y", (d) => yScale(d.x0))
          .attr("width", (d) => xScale(d.realDensity))
          .attr("height", (d, i, all) => yScale(d.x0) - yScale(d.x1) - 1)
          .append("title")
          .text(
            (d) =>
              `${d.x0} ${d.x1} ${d.length} subsetLength ${Y.length} densitiy ${
                d.length / Y.length
              } realDensity ${d.realDensity}`
          );
      })
      .attr(
        "transform",
        ({ id, bins, densities }) =>
          `translate(${gScale(id) + gScale.bandwidth() / 2}, 0)`
      );
  }

  // if (title) bar.append("title")
  //     .text(title);

  return svg.node();
}
)}

function _FacetViolinPlot(width,d3,ViolinPlot,htl,html){return(
(
  data,
  {
    columns = 2,
    facetBy = null, // provide either facetBy a function to the attribute to face
    attribs = [], // or a list of attributes to useß, width
    violinOptions = {
      width: width / columns,
      height: 150
    }
  } = {}
) => {
  attribs = attribs || d3.groups(data, facetBy).map((d) => d[0]);
  const getViolinFacet = (attr) =>
    ViolinPlot(data, { ...violinOptions, value: (d) => d[attr] });
  return htl.html`<div style="display:flex; flex-wrap: wrap">
${attribs.map(
  (attr) =>
    html`<div style="flex: ${100 / columns}%">
<h2>${attr}</h2>
  ${getViolinFacet(attr)}
</div>`
)}
</div>`;
}
)}

function _values1d(penguins){return(
penguins.map((d) => d.culmen_length_mm)
)}

function _pk(kde,penguins,bandwidth,pad,thresholds){return(
kde.density1d(
  penguins.map((d) => d.culmen_length_mm),
  {
    bandwidth,
    pad,
    bins: thresholds
  }
)
)}

function _19(Plot,pk,bandwidth,values1d,width){return(
Plot.plot({

  y: { grid: true },
  marks: [
    // use bandwidth method to update efficiently without re-binning
    Plot.areaY(pk.bandwidth(bandwidth), {x: 'x', y: 'y', fill: '#ccc' }),
    Plot.dot(values1d, {x: d => d, y: 0, fill: 'black' })
  ],
  width,
  height: 250
})
)}

function _kde(require){return(
require("fast-kde")
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["SF_Employee_Compensation_2022.csv", {url: new URL("./files/54a400faf07a47116e923efc7555f511cf37383befe63222ae46cf89b36d145b81d1c6b48bb100816fc808a2085d185c62b0918397b0b0d64a347f248901c68d.csv", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("viewof bandwidth")).define("viewof bandwidth", ["Inputs"], _bandwidth);
  main.variable(observer("bandwidth")).define("bandwidth", ["Generators", "viewof bandwidth"], (G, _) => G.input(_));
  main.variable(observer("viewof thresholds")).define("viewof thresholds", ["Inputs"], _thresholds);
  main.variable(observer("thresholds")).define("thresholds", ["Generators", "viewof thresholds"], (G, _) => G.input(_));
  main.variable(observer("viewof pad")).define("viewof pad", ["Inputs"], _pad);
  main.variable(observer("pad")).define("pad", ["Generators", "viewof pad"], (G, _) => G.input(_));
  main.variable(observer("viewof drawBars")).define("viewof drawBars", ["Inputs"], _drawBars);
  main.variable(observer("drawBars")).define("drawBars", ["Generators", "viewof drawBars"], (G, _) => G.input(_));
  main.variable(observer("viewof drawHistogram")).define("viewof drawHistogram", ["Inputs"], _drawHistogram);
  main.variable(observer("drawHistogram")).define("drawHistogram", ["Generators", "viewof drawHistogram"], (G, _) => G.input(_));
  main.variable(observer("viewof drawPoints")).define("viewof drawPoints", ["Inputs"], _drawPoints);
  main.variable(observer("drawPoints")).define("drawPoints", ["Generators", "viewof drawPoints"], (G, _) => G.input(_));
  main.variable(observer("viewof groupBy")).define("viewof groupBy", ["Inputs"], _groupBy);
  main.variable(observer("groupBy")).define("groupBy", ["Generators", "viewof groupBy"], (G, _) => G.input(_));
  main.variable(observer("chart")).define("chart", ["ViolinPlot","penguins","groupBy","width","color","bandwidth","thresholds","pad","drawBars","drawPoints","drawHistogram"], _chart);
  main.variable(observer("facetedChart")).define("facetedChart", ["FacetViolinPlot","penguins","groupBy","color","bandwidth","thresholds","pad","drawBars","drawPoints","drawHistogram"], _facetedChart);
  main.variable(observer("color")).define("color", ["d3"], _color);
  main.variable(observer("chart2")).define("chart2", ["ViolinPlot","compensation","width","bandwidth","thresholds","pad","drawBars"], _chart2);
  main.variable(observer("compensation")).define("compensation", ["FileAttachment"], _compensation);
  main.variable(observer()).define(["howto"], _14);
  main.variable(observer("ViolinPlot")).define("ViolinPlot", ["d3","kde"], _ViolinPlot);
  main.variable(observer("FacetViolinPlot")).define("FacetViolinPlot", ["width","d3","ViolinPlot","htl","html"], _FacetViolinPlot);
  main.variable(observer("values1d")).define("values1d", ["penguins"], _values1d);
  main.variable(observer("pk")).define("pk", ["kde","penguins","bandwidth","pad","thresholds"], _pk);
  main.variable(observer()).define(["Plot","pk","bandwidth","values1d","width"], _19);
  const child1 = runtime.module(define1);
  main.import("howto", child1);
  main.import("altplot", child1);
  main.variable(observer("kde")).define("kde", ["require"], _kde);
  return main;
}
