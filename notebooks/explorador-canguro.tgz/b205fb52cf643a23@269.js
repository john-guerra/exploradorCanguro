import define1 from "./1371b3b2446a73b4@335.js";

function _1(md){return(
md`# To Stages`
)}

function _data(dataInput){return(
dataInput()
)}

function _3(data){return(
data
)}

function _xAttr(){return(
"__stageId"
)}

function _yAttr(){return(
"peso"
)}

function _groupAttr(){return(
"Iden_Codigo"
)}

function _renderer(){return(
"canvas"
)}

function _stages()
{
  var a = [
    {
      id: 0,
      name: "Entorno",
      variables: []
    },
    {
      id: 1,
      name: "Embarazo y pre-parto",
      variables: []
    },
    {
      id: 2,
      time: "ERN_Ballard",
      name: "Nacimiento",
      variables: [
        {
          name: "peso",
          var: "ERN_Peso"
        },
        {
          name: "talla",
          var: "ERN_Talla"
        },
        {name: "PC",
        var: "ERN_PC"}
      ]
    },
    {
      id: 3,
      time: "gestasal",
      name: "hosp-neonatal",
      variables: [
        {
          name: "peso",
          var: "HD_PesoSalida"
        }
      ]
    },
    {
      id: 4,
      time: "egestasalPC",
      name: "Entrada Programa Canguro",
      variables: [
        {
          name: "peso",
          var: "V196A"
        },
        {
          name: "talla",
          var: "V196B"
        },
        {name: "PC",
        var: "V196C"}
      ]
    },
    {
      id: 5,
      name: "Semana 40",
      time: 40,
      variables: [
        {
          name: "peso",
          var: "V218"
        },
        {
          name: "talla",
          var: "V219"
        },
        {
          name: "PC",
          var: "V220"
        }
      ]
    },
    {
      id: 6,
      name: "Mes 3",
      time: 53,
      variables: [
        {
          name: "peso",
          var: "V261"
        },
        {
          name: "talla",
          var: "V262"
        },
        {
          name: "PC",
          var: "V263"
        }
      ]
    },
    {
      id: 7,
      name: "Mes 6",
      time: 66,
      variables: [
        {
          name: "peso",
          var: "V304"
        },
        {
          name: "talla",
          var: "V305"
        },
        {
          name: "PC",
          var: "V306"
        }
      ]
    },
    {
      id: 8,
      name: "Mes 9",
      time: 79,
      variables: [
        {
          name: "peso",
          var: "V347"
        },
        {
          name: "talla",
          var: "V348"
        },
        {
          name: "PC",
          var: "V349"
        }
      ]
    },
    {
      id: 9,
      name: "Mes 12",
      time: 92,
      variables: [
        {
          name: "peso",
          var: "V389"
        },
        {
          name: "talla",
          var: "V390"
        },
        {
          name: "PC",
          var: "V391"
        }
      ]
    }
  ];

  return a;
}


function _dataF(data){return(
data
)}

function _grouped(d3,tData){return(
d3.group(tData, d => d["Code"])
)}

function _tData(transformData,dataF,stages){return(
transformData(dataF,"Code",stages,"ERN_Sexo")
)}

function _transformData(){return(
function transformData(data, ident, stages, groupAttr) {
  let tData = [];
  stages.forEach((stage) => {
     data.forEach((r) => {
      let time = typeof(stage.time) === "number" ? stage.time : r[stage.time] 
      let row = { [ident]: r[ident], __stageName: stage.name, __stageId: stage.id, __time: time}
      if (groupAttr) {
        row = {...row,[groupAttr]: r[groupAttr]};
      }
       if (stage.variables.length > 0) {
      stage.variables.forEach(v =>{
        row = {...row, [v.name]: r[v.var]}
      })
       tData.push(row)
       }
    });
  });
  return tData;
}
)}

function _computeId(){return(
function computeId (data,key1,key2) {
  data.forEach(d => d["__Id"] = d[key1] + 100000 * d[key2])
  return data;
}
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("viewof data")).define("viewof data", ["dataInput"], _data);
  main.variable(observer("data")).define("data", ["Generators", "viewof data"], (G, _) => G.input(_));
  main.variable(observer()).define(["data"], _3);
  main.variable(observer("xAttr")).define("xAttr", _xAttr);
  main.variable(observer("yAttr")).define("yAttr", _yAttr);
  main.variable(observer("groupAttr")).define("groupAttr", _groupAttr);
  main.variable(observer("renderer")).define("renderer", _renderer);
  main.variable(observer("stages")).define("stages", _stages);
  main.variable(observer("dataF")).define("dataF", ["data"], _dataF);
  main.variable(observer("grouped")).define("grouped", ["d3","tData"], _grouped);
  main.variable(observer("tData")).define("tData", ["transformData","dataF","stages"], _tData);
  main.variable(observer("transformData")).define("transformData", _transformData);
  main.variable(observer("computeId")).define("computeId", _computeId);
  const child1 = runtime.module(define1);
  main.import("dataInput", child1);
  return main;
}
