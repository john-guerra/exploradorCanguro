import define1 from "./e76d2c695f356743@796.js";
import define2 from "./a1fd3857bac219b0@480.js";
import define3 from "./600f1f80e771a771@509.js";
import define4 from "./b205fb52cf643a23@269.js";
import define5 from "./73237496f9892bc2@199.js";
import define6 from "./30a89c211b68b9cd@194.js";
import define7 from "./a33468b95d0b15b0@808.js";
import define8 from "./529f9a5a4dd1dd5a@425.js";
import define9 from "./ead85c616c9dadd5@1337.js";

function _1(md){return(
md`# Explorador Canguro Mar 6 2023

Proyecto Canguro 2023
Kangaroo Project March 2023

Despliegue

https://john-guerra.github.io/exploradorCanguro/

Diseño

https://www.figma.com/file/g48H9mtm08T3IYDop2GFGz/Fundaci%C3%B3n-Canguro?t=fxcIxgz7IcrkUVPN-0

Modules

* Importer
  - CSV / JSON
* Filterer
  - Navio
  - Data Filterer
  - Time Searcher 
* Data manipulator
  - https://observablehq.com/@observablehq/data-wrangler ?
  - Corrected Age
  - Align all kids by corrected age
* Groups Manager
  - ?
* Comparison
  - 
* Exporting
  - ?

Kanguro
Canguro
Kangaroo

## Changelog

* @952 2024 Oct 23, added the data again`
)}

function _attribWidth(Inputs){return(
Inputs.range([2, 50], {label: "Ancho atributos", value: this?.value || 8, step: 1})
)}

function _height(Inputs){return(
Inputs.range([100, 900], {label: "Tamaño Navio", value: 500})
)}

function _5(md){return(
md`# Filtrar Muestra de Análisis`
)}

function _attribs(data,searchCheckbox)
{
  const allAttribs = Object.keys(data[0]);

  return searchCheckbox(allAttribs, {
    label: "Atributos",
    height: 150,
    value: [
      "RCIUFenton",
      "ERN_Ballard"
    ]
  });
}


function _7(md){return(
md`## Grupo 1: `
)}

function _nameG1(Inputs){return(
Inputs.text({label: "Name of group: ", value: "HPreNoRCIU"})
)}

function _G1(FacetedSearch,dataF,attribs){return(
FacetedSearch(dataF, {
  attribs:  attribs
  //filterData: filterDataJS
})
)}

function _10(md){return(
md`## Grupo 2:`
)}

function _nameG2(Inputs){return(
Inputs.text({label: "Name of group: ",value: "HPreRCIU"})
)}

function _G2(FacetedSearch,dataF,attribs){return(
FacetedSearch(dataF, {
  attribs:  attribs
  //filterData: filterDataJS
})
)}

function _13(md){return(
md`# Seleccionar grupos de trabajo`
)}

function _14(maxTimelines,selectedStages,data,htl,divTimeSearcher,brushCoordinatesElement,brushesControlsElement,divDetails)
{
  maxTimelines; selectedStages; data;
  return htl.html`
  <div>
    <div style="display:flex">
      <div flex=3>${divTimeSearcher}</div>
      <div flex=1>
        ${brushCoordinatesElement}
        <br/>
        ${brushesControlsElement} 
      </div>
    </div>
      ${divDetails}
  </div>
`
}


function _statsCardChart(StatisticalCard,SelectedTime,configImpact,brushesScale){return(
StatisticalCard(SelectedTime,{config:configImpact, colorScale: brushesScale})
)}

function _violinsChart(SelectedTime,FacetViolinPlot,attribsImpact,brushesScale)
{

  let tidySelectedTime = [];
  SelectedTime.forEach((v, i) => {
    v.map((d) => Object.assign(d, { __violin_group: `g${i + "_" + d.__group}` }))
    tidySelectedTime = tidySelectedTime.concat(v);
  }
  )// fold the data to tidy format adding a group attribute
  
  return FacetViolinPlot(tidySelectedTime, {
    attribs: attribsImpact,
    violinOptions: {
      y: (d) => +d[attribsImpact[0]],
      groupBy : d => d.__violin_group,
      color: d => {  ; let groupId = +d.id?.substr(1,1)
        if (!isNaN(groupId)) {
          return  brushesScale(groupId)
        }
      },
      drawPoints: true,
      // drawHistogram: true,
    }
  });
}


function _comparisonChart(comparisionCard,SelectedTime,configImpact,brushesScale){return(
comparisionCard(SelectedTime, { config: configImpact, colorScale: brushesScale })
)}

function _attribsImpact(data,searchCheckbox)
{
  const allAttribs = Object.keys(data[0]).filter(a => !isNaN(data[0][a])); // only use quant attribs

  return searchCheckbox(allAttribs, {
    label: "Atributos",
    height: 150,
    value: this?.value /* keep previous value */ || [
      "V389",
      "CD12"
    ]
  });
}


function _19(md){return(
md`# Selección de variables de impacto`
)}

function _SelectedTimeId(TimeSearcher,divTimeSearcher,brushesControlsElement,width,brushCoordinatesElement,fmtX,fmtY,divDetails,maxTimelines,brushesScale,d3,selectedStages,curvas)
{
  const tsEle = TimeSearcher({
    target: divTimeSearcher,
    brushesControlsElement,
    showBrushesControls: true,
    y: "peso",
    x: "__time",
    id: "Code",
    xLabel: "→ EG (Weeks)",
    yLabel: "↑ Talla (Cm)",
    width: width,
    height: 400,
    brushCoordinatesElement,
    fmtX,
    fmtY,
    detailsElement: divDetails,
    detailsWidth: width,
    detailsHeight: 200,
    maxdetailsRecords: 100,
    maxTimelines,
    medianNumBins:10,
    hasDetails: true,
    groupAttr: "__group",
    noSelectedAlpha: 0.1,
    brushesColorScale: brushesScale,
    alphaScale: d3.scalePow().exponent(0.2).range([1, 0.1])
  });

  // see update
  // https://observablehq.com/@ivelascog/timesearcher-plus-usabilidad#selected
  tsEle.ts.doubleYlegend = true;  
  tsEle.ts.margin.right = 50;
  tsEle.ts.showGrid = true;
  tsEle.ts.stepX = 1;
  tsEle.ts.stepY = 100;
  tsEle.ts.data(selectedStages);
  tsEle.ts.addReferenceCurves(curvas);
  

  return tsEle;
}


function _groupsScale(d3){return(
d3.scaleOrdinal(["#1b9e77","#d95f02","#7570b3","#e7298a","#66a61e","#e6ab02","#a6761d","#666666"])
)}

function _brushesScale(d3){return(
d3.scaleOrdinal(["#fdc086","#386cb0","#f0027f","#bf5b17","#666666"])
)}

function _23(G1,G2,Swatches,groupsScale)
{ 
  G1; G2 // make it reactive on filter updates
  return Swatches(groupsScale, {label: "Grupos"})
}


function _24(G1,G2,Swatches,brushesScale)
{
  G1; G2 // make it reactive on filter updates
  return Swatches(brushesScale, {label: "Grupos"})
}


function _25(md){return(
md`# Descriptores Estadísticos`
)}

function _26(configImpact){return(
configImpact
)}

function _27(md){return(
md`# Cálculos intermedios`
)}

function _28(SelectedTime){return(
SelectedTime
)}

function _configImpact(attribsImpact)
{
  let object = []
  attribsImpact.forEach(d => {
    let statistics = ["mean","deviation"]
    let comparison = ["anova"]
    let o = {name: d, var: d, statistics: statistics, comparison:comparison}
    object.push(o)
  })
  return object
}


function _brushesControlsElement(maxTimelines,selectedStages,data,htl)
{
  maxTimelines; selectedStages; data;
  return htl.html`<div></div>`
}


function _width(){return(
700
)}

function _brushCoordinatesElement(maxTimelines,selectedStages,data,htl)
{
  maxTimelines; selectedStages; data;
  return htl.html`<div>`
}


function _divDetails(maxTimelines,selectedStages,data,htl)
{
  maxTimelines; selectedStages; data;
  return htl.html`<div>Details</div>`;
}


function _divTimeSearcher(maxTimelines,selectedStages,data,htl)
{
  maxTimelines; selectedStages; data;
  return htl.html`<div></div>`;
}


function _fmtX(d3){return(
d3.format(".1f")
)}

function _fmtY(d3){return(
d3.format(".2d")
)}

function _maxTimelines(){return(
5000
)}

function _data(FileAttachment){return(
FileAttachment("KMC-50k-Base 1993-2022 Jul -20220929@1.csv.zip")
  .zip()
  .then((res) => res.file("KMC-50k-Base 1993-2022 Jul -20220929.csv").csv({ typed: true }))
)}

function _curvas(FileAttachment){return(
FileAttachment("curvasv2.json").json()
)}

function _selectedStages(transformData,G1G2,stages){return(
transformData(G1G2, "Code", stages, "__group").filter(
  (d) => d["peso"] < 15000 && d["__time"] > 20 && d["__time"] < 93
)
)}

function _47(G2){return(
G2
)}

function _G1G2(G1,G2){return(
G1.concat(G2)
)}

function _SelectedTime(SelectedTimeId,dataF)
{
  let aux = new Map();
  SelectedTimeId.forEach((g, id) => {
    let gIds = new Set(g.map((d) => d[0]));
    let gData = dataF.filter((d) => gIds.has(d["Code"]) && d["V389"] < 16000);
    aux.set(id, gData);
  });

  return aux;
}


function _50(SelectedTimeId){return(
SelectedTimeId
)}

function _dataF(data){return(
data.filter(d => d["ERN_Ballard"] < 50 && d["ERN_Ballard"] > 20)
)}

function _updateG1(G1,nameG1){return(
G1.forEach(d => d["__group"] = nameG1)
)}

function _updateG2(G2,nameG2){return(
G2.forEach(d => d["__group"] = nameG2)
)}

async function _TimeSearcher(require,FileAttachment)
{
  try {
    return await require(`http://localhost:8080/dist/TimeSearcher.js?${Date.now()}`)
  } catch (e) {
     return await require(await FileAttachment("TimeSearcher@4.js").url())
  }
}


export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["curvasv2.json", {url: new URL("./files/8ee21262e803e5bb01fd671b721f4c8e6aaf2ca8342a2c311d609939468557bcd291c86b303fa24dd2938fddbb1d925ff5f3346caf6bd3ab39e35192908b876a.json", import.meta.url), mimeType: "application/json", toString}],
    ["TimeSearcher@4.js", {url: new URL("./files/e4e1f492018f944abd5e23a864558cad1c249ab605a45cb31cabd9b31fdf7d1422d7a4e40c22b72dcee398c2c77174690528a701885c5a9a25f4c597b0c0284b.js", import.meta.url), mimeType: "application/javascript", toString}],
    ["KMC-50k-Base 1993-2022 Jul -20220929@1.csv.zip", {url: new URL("./files/c8e1755722d63b66ac646c206183a42e8d4308dd83438f6e6cc606c5ceda14d7f63ea82db619867fd581b14e466dcc9b2639171dff7e82be1f597474c91d533d.zip", import.meta.url), mimeType: "application/zip", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("viewof attribWidth")).define("viewof attribWidth", ["Inputs"], _attribWidth);
  main.variable(observer("attribWidth")).define("attribWidth", ["Generators", "viewof attribWidth"], (G, _) => G.input(_));
  main.variable(observer("viewof height")).define("viewof height", ["Inputs"], _height);
  main.variable(observer("height")).define("height", ["Generators", "viewof height"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _5);
  main.variable(observer("viewof attribs")).define("viewof attribs", ["data","searchCheckbox"], _attribs);
  main.variable(observer("attribs")).define("attribs", ["Generators", "viewof attribs"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _7);
  main.variable(observer("viewof nameG1")).define("viewof nameG1", ["Inputs"], _nameG1);
  main.variable(observer("nameG1")).define("nameG1", ["Generators", "viewof nameG1"], (G, _) => G.input(_));
  main.variable(observer("viewof G1")).define("viewof G1", ["FacetedSearch","dataF","attribs"], _G1);
  main.variable(observer("G1")).define("G1", ["Generators", "viewof G1"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _10);
  main.variable(observer("viewof nameG2")).define("viewof nameG2", ["Inputs"], _nameG2);
  main.variable(observer("nameG2")).define("nameG2", ["Generators", "viewof nameG2"], (G, _) => G.input(_));
  main.variable(observer("viewof G2")).define("viewof G2", ["FacetedSearch","dataF","attribs"], _G2);
  main.variable(observer("G2")).define("G2", ["Generators", "viewof G2"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _13);
  main.variable(observer()).define(["maxTimelines","selectedStages","data","htl","divTimeSearcher","brushCoordinatesElement","brushesControlsElement","divDetails"], _14);
  main.variable(observer("statsCardChart")).define("statsCardChart", ["StatisticalCard","SelectedTime","configImpact","brushesScale"], _statsCardChart);
  main.variable(observer("violinsChart")).define("violinsChart", ["SelectedTime","FacetViolinPlot","attribsImpact","brushesScale"], _violinsChart);
  main.variable(observer("comparisonChart")).define("comparisonChart", ["comparisionCard","SelectedTime","configImpact","brushesScale"], _comparisonChart);
  main.variable(observer("viewof attribsImpact")).define("viewof attribsImpact", ["data","searchCheckbox"], _attribsImpact);
  main.variable(observer("attribsImpact")).define("attribsImpact", ["Generators", "viewof attribsImpact"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _19);
  main.variable(observer("viewof SelectedTimeId")).define("viewof SelectedTimeId", ["TimeSearcher","divTimeSearcher","brushesControlsElement","width","brushCoordinatesElement","fmtX","fmtY","divDetails","maxTimelines","brushesScale","d3","selectedStages","curvas"], _SelectedTimeId);
  main.variable(observer("SelectedTimeId")).define("SelectedTimeId", ["Generators", "viewof SelectedTimeId"], (G, _) => G.input(_));
  main.variable(observer("groupsScale")).define("groupsScale", ["d3"], _groupsScale);
  main.variable(observer("brushesScale")).define("brushesScale", ["d3"], _brushesScale);
  main.variable(observer()).define(["G1","G2","Swatches","groupsScale"], _23);
  main.variable(observer()).define(["G1","G2","Swatches","brushesScale"], _24);
  main.variable(observer()).define(["md"], _25);
  main.variable(observer()).define(["configImpact"], _26);
  main.variable(observer()).define(["md"], _27);
  main.variable(observer()).define(["SelectedTime"], _28);
  main.variable(observer("configImpact")).define("configImpact", ["attribsImpact"], _configImpact);
  main.variable(observer("brushesControlsElement")).define("brushesControlsElement", ["maxTimelines","selectedStages","data","htl"], _brushesControlsElement);
  main.variable(observer("width")).define("width", _width);
  main.variable(observer("brushCoordinatesElement")).define("brushCoordinatesElement", ["maxTimelines","selectedStages","data","htl"], _brushCoordinatesElement);
  main.variable(observer("divDetails")).define("divDetails", ["maxTimelines","selectedStages","data","htl"], _divDetails);
  main.variable(observer("divTimeSearcher")).define("divTimeSearcher", ["maxTimelines","selectedStages","data","htl"], _divTimeSearcher);
  main.variable(observer("fmtX")).define("fmtX", ["d3"], _fmtX);
  main.variable(observer("fmtY")).define("fmtY", ["d3"], _fmtY);
  main.variable(observer("maxTimelines")).define("maxTimelines", _maxTimelines);
  const child1 = runtime.module(define1);
  main.import("navio", child1);
  main.variable(observer("data")).define("data", ["FileAttachment"], _data);
  main.variable(observer("curvas")).define("curvas", ["FileAttachment"], _curvas);
  main.variable(observer("selectedStages")).define("selectedStages", ["transformData","G1G2","stages"], _selectedStages);
  main.variable(observer()).define(["G2"], _47);
  main.variable(observer("G1G2")).define("G1G2", ["G1","G2"], _G1G2);
  main.variable(observer("SelectedTime")).define("SelectedTime", ["SelectedTimeId","dataF"], _SelectedTime);
  main.variable(observer()).define(["SelectedTimeId"], _50);
  main.variable(observer("dataF")).define("dataF", ["data"], _dataF);
  main.variable(observer("updateG1")).define("updateG1", ["G1","nameG1"], _updateG1);
  main.variable(observer("updateG2")).define("updateG2", ["G2","nameG2"], _updateG2);
  const child2 = runtime.module(define2);
  main.import("Treemap", child2);
  const child3 = runtime.module(define3);
  main.import("searchCheckbox", child3);
  const child4 = runtime.module(define4);
  main.import("transformData", child4);
  main.import("stages", child4);
  const child5 = runtime.module(define5);
  main.import("StatisticalCard", child5);
  main.import("config", child5);
  const child6 = runtime.module(define6);
  main.import("comparisionCard", child6);
  const child7 = runtime.module(define7);
  main.import("Swatches", child7);
  const child8 = runtime.module(define8);
  main.import("FacetedSearch", child8);
  const child9 = runtime.module(define9);
  main.import("ViolinPlot", child9);
  main.import("FacetViolinPlot", child9);
  main.variable(observer("TimeSearcher")).define("TimeSearcher", ["require","FileAttachment"], _TimeSearcher);
  return main;
}
