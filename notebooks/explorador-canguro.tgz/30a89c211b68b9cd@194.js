import define1 from "./1371b3b2446a73b4@335.js";
import define2 from "./600f1f80e771a771@509.js";
import define3 from "./73237496f9892bc2@199.js";

function _1(md){return(
md`# Comparison Cards`
)}

function _data(dataInput){return(
dataInput()
)}

function _dataS(data)
{
  let d = new Map();
  d.set(0,data.slice(0,250));
  d.set(1,data.slice(250,500));
  d.set(2,data.slice(500,750));
  d.set(3,data.slice(750,1000))
  return d;
}


function _4(comparisionCard,dataS,config){return(
comparisionCard(dataS,{config:config})
)}

function _comparisionCard(d3,_anova){return(
function comparisionCard(
  data,
  { config, _staticsFunctions = {}, _comparisonFunctions = {}, colorScale= d3.scaleOrdinal(d3.schemeAccent)  }
) {
  let div = d3
    .create("div")
    .style("display", "flex")
    //.style("background-color", "gray")
    .style("width", "fit-content");

  let staticsFunction = {
    mean: d3.mean,
    deviation: d3.deviation,
    min: d3.min,
    max: d3.max,
    ..._staticsFunctions
  };

  let comparisonFunction = {
    anova: anova,
    ..._comparisonFunctions
  };

  if (data.size >= 2) {
    let pData = processData(data, config);
    console.log(pData);
    generateCard(pData);
  }

  function generateCard(data) {
   let varDivs = div
     .selectAll("vContainer")
     .data(data)
      .join("div")
      .attr("class", "vContainer")
      .style("margin", "10px")
      .style("background", d => `linear-gradient(to right, ${colorScale(d.g1)} 50%, ${colorScale(d.g2)} 50%)`)
      .style("padding-right", "10px")
      .style("padding-left", "10px")
      .style("border-radius", "20px")
      .selectAll(".var")
      .data(d => d.vars)
      .join("div")
      .attr("class", "var");

    varDivs.append("span").text((d) => d.name + " :");

    let uls = varDivs.append("ul").style("margin-top", "0px");

    uls
      .selectAll(".statistics")
      .data((d) => d.statistics)
      .join("li")
      .attr("class", "statistics")
      .text((d) => d.name + " diff: " + d.value?.toFixed(2));

    uls
      .selectAll(".comparision")
      .data((d) => d.comparision)
      .join("li")
      .attr("class", "comparision")
      .text((d) => d.name + ": " + d.value?.toFixed(2));
  }

  function processData(data, config) {
    let keys = Array.from(data.keys());
    let indexCombination = keys.flatMap((v, i) =>
      keys.slice(i + 1).map((w) => [v, w])
    );

    let outData = [];
    indexCombination.forEach(([ix1, ix2]) => {
      let varData = [];
      config.forEach((variable) => {
        let calculatedDiffs = [];
        variable.statistics.forEach((statistic) => {
          let varValue0 = computeStatistic(
            data.get(ix1),
            variable.var,
            statistic
          );
          let varValue1 = computeStatistic(
            data.get(ix2),
            variable.var,
            statistic
          );
          let result = varValue0 - varValue1;
          calculatedDiffs.push({ name: statistic, value: result });
        });

        let calculateTests = [];
        variable.comparison.forEach((test) => {
          let result = computeTest(
            [data.get(ix1), data.get(ix2)],
            variable.var,
            test
          );
          calculateTests.push({ name: test, value: result });
        });

        varData.push({
          name: variable.name,
          statistics: calculatedDiffs,
          comparision: calculateTests
        });
      });

      outData.push({
        g1: ix1,
        g2: ix2,
        vars: varData
      });
    });

    return outData;
  }

  function computeStatistic(data, varName, statistic) {
    return staticsFunction[statistic](data.map((d) => d[varName]));
  }

  function computeTest(datas, varName, test) {
    let samples0 = datas[0].map((d) => d[varName]);
    let samples1 = datas[1].map((d) => d[varName]);
    samples0 = samples0.filter((d) => d !== undefined && d !== null);
    samples1 = samples1.filter((d) => d !== undefined && d !== null);
    return comparisonFunction[test](samples0, samples1);
  }

  function anova(samples0, samples1) {
    if (samples0 < 1 && samples1 < 1) {
      return undefined;
    }
    let group0 = Array(samples0.length).fill(0);
    let group1 = Array(samples1.length).fill(1);
    let samples = samples0.concat(samples1);
    let group = group0.concat(group1);
    let result = _anova.default(samples, group);
    console.log(result);
    return result.pValue;
  }

  return div.node();
}
)}

function _6(config){return(
config
)}

function _d3(require){return(
require("d3@7")
)}

function __anova(){return(
import('https://cdn.skypack.dev/@stdlib/stats-anova1@0.0.7?min')
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("viewof data")).define("viewof data", ["dataInput"], _data);
  main.variable(observer("data")).define("data", ["Generators", "viewof data"], (G, _) => G.input(_));
  main.variable(observer("dataS")).define("dataS", ["data"], _dataS);
  main.variable(observer()).define(["comparisionCard","dataS","config"], _4);
  main.variable(observer("comparisionCard")).define("comparisionCard", ["d3","_anova"], _comparisionCard);
  main.variable(observer()).define(["config"], _6);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  const child1 = runtime.module(define1);
  main.import("dataInput", child1);
  const child2 = runtime.module(define2);
  main.import("searchCheckbox", child2);
  main.variable(observer("_anova")).define("_anova", __anova);
  const child3 = runtime.module(define3);
  main.import("config", child3);
  return main;
}
