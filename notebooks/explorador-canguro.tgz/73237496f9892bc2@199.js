import define1 from "./1371b3b2446a73b4@335.js";

function _1(md){return(
md`# Statistical card`
)}

function _data(dataInput){return(
dataInput()
)}

function _dataS(data)
{
  let d = new Map();
  d.set(0,data.slice(0,500));
  return d;
}


function __staticsFunction(d3)
{
  return {min: d3.min}
}


function _config(){return(
[
  {
    name: "peso 12",
    var: "V389",
    statistics : [
      "mean","deviation"
    ],
    comparison: [
      "anova"
    ]
  },
  {
    name: "CD12",
    var: "CD12",
    statistics: [
      "mean","deviation","min"
    ],
    comparison: [
      "anova"
    ]
  }
]
)}

function _6(StatisticalCard,dataS,config,_staticsFunction,d3){return(
StatisticalCard(dataS,{config: config,_staticsFunctions : _staticsFunction, colorScale:d3.scaleOrdinal(d3.schemeAccent) })
)}

function _StatisticalCard(d3){return(
function StatisticalCard(datas, {config, _staticsFunctions = {}, colorScale = d3.scaleOrdinal(d3.schemeCategory10) } ) {
  let div = d3
    .create("div")
    .style("display", "flex")
    //.style("background-color", "gray")
    .style("width","fit-content")
  
  let staticsFunction = {
    mean: d3.mean,
    deviation: d3.deviation,
    min: d3.min,
    max: d3.max,
    ..._staticsFunctions
  };

  let pData = generateGroups(datas, config);
  addVisualDataGroup(pData);

  function addVisualDataGroup(data) {
    let groupDivs = div
      .selectAll(".vContainet")
      .data(data)
      .join("div")
      .attr("class", "vContainer")
      .style("margin", "10px")
      .style("background-color", (d) => colorScale(d.id))
      .style("padding-right","10px")
      .style("padding-left", "10px")
      .style("border-radius", "20px")

    groupDivs.append("span").text(g => "Count: " + g.count)
      
      groupDivs.each(function (g) {
        let varDivs = d3
          .select(this)
          .selectAll(".var")
          .data(g.variables)
          .join("div")
          .attr("class", "var")

        varDivs.append("span").text((d) => d.name + ":");

        varDivs
          .append("ul")
          .style("margin-top","0px")
          .selectAll(".statistics")
          .data((d) => d.statistics)
          .join("li")
          .attr("class", "statistics")
          .text((d) => d.name + ": " + d.value?.toFixed(2));
      });
  }
  function generateGroups(datas, config) {
    let outData = [];
    datas.forEach((data, i) => {
      let variablesCalculated = [];
      config.forEach((variable) => {
        let statisticCalculated = [];
        variable.statistics.forEach((statistic) => {
          statisticCalculated.push({
            name: statistic,
            value: computeStatistic(data, variable.var, statistic)
          });
        });
        variablesCalculated.push({
          name: variable.name,
          statistics: statisticCalculated
        });
      });
      outData.push({ id: i, variables: variablesCalculated, count: data.length });
    });

    return outData;
  }

  function computeStatistic(data, varName, statistic) {
    return staticsFunction[statistic](data, (d) => d[varName]);
  }

  return div.node();
}
)}

function _d3(require){return(
require("d3@7")
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("viewof data")).define("viewof data", ["dataInput"], _data);
  main.variable(observer("data")).define("data", ["Generators", "viewof data"], (G, _) => G.input(_));
  main.variable(observer("dataS")).define("dataS", ["data"], _dataS);
  main.variable(observer("_staticsFunction")).define("_staticsFunction", ["d3"], __staticsFunction);
  main.variable(observer("config")).define("config", _config);
  main.variable(observer()).define(["StatisticalCard","dataS","config","_staticsFunction","d3"], _6);
  main.variable(observer("StatisticalCard")).define("StatisticalCard", ["d3"], _StatisticalCard);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  const child1 = runtime.module(define1);
  main.import("dataInput", child1);
  return main;
}
